#!/usr/bin/python

# PyShoutOut by Joey C. (http://www.joeyjwc.x3fusion.com)
# Read the data from a shout-out file.


# Changed by Matthias Strubel / 2011-02-27 for piratebox-path

from psogen import generate_html_to_display_from_file 

print "Content-type:text/html\r\n\r\n"

generate_html_to_display_from_file()

